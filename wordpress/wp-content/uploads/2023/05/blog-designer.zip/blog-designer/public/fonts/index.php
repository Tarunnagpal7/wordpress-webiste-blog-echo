<?php

# Silence is golden.